---
name: learning-loop-studymate
description: 将十步学习闭环的五视角调研和核心路径交接给 StudyMate 建课，或读取 StudyMate 评估记录做复盘。用户明确要两套学习流程联动时使用。
---

# 学习闭环 × StudyMate 入口

读取 [主学习技能](../learning-loop/SKILL.md) 与其 [StudyMate 联动协议](../learning-loop/references/StudyMate联动.md)。先判断请求是新课交接、已有课程续学，还是从 StudyMate 回流复盘。仅加载该方向所需的十步执行手册段落。

入口话术：`$learning-loop-studymate 我想学【主题】，目标是【成果】；先做五视角调研，再交给 StudyMate 建课。学习工作区是【绝对路径，可暂不填】。`

StudyMate 的 Codex 总控名为 `learning-system`。若已安装完整 StudyMate 插件，按联动协议传入交接简报，让总控接管课程、课件、进度与评估；若只有源码，先生成可复用的交接简报并明确说明尚未运行 StudyMate。不得把源码目录当学习工作区，也不得把建议级的地图写成已验证掌握度。
